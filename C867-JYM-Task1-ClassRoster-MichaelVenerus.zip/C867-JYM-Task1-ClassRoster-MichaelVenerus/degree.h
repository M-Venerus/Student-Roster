#pragma once
#ifndef degree_h
#define degree_h

//Define degree types of students
enum class DegreeProgram : int {SECURITY,NETWORK,SOFTWARE};

#endif